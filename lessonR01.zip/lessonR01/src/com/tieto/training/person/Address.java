package com.tieto.training.person;

import java.util.Objects;
import java.util.StringJoiner;

public class Address {
    private final String street;
    private final String city;

    private Address(final Builder builder) {
        this.street = builder.street;
        this.city = builder.city;
    }

    public String getStreet() {
        return street;
    }

    public String getCity() {
        return city;
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Address)) {
            return false;
        }
        final Address address = (Address) o;
        return Objects.equals(street, address.street) &&
                Objects.equals(city, address.city);
    }

    @Override
    public int hashCode() {
        return Objects.hash(street, city);
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", Address.class.getSimpleName() + "[", "]")
                .add("street='" + street + "'")
                .add("city='" + city + "'")
                .toString();
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private String street;
        private String city;

        private Builder() {}

        public Builder street(final String street) {
            this.street = street;
            return this;
        }

        public Builder city(final String city) {
            this.city = city;
            return this;
        }

        public Address build() {
            // Here would be consistency check
            return new Address(this);
        }
    }
}
