package com.tieto.training.person;

import java.time.LocalDate;
import java.time.Month;
import java.util.Objects;
import java.util.StringJoiner;

public class Person implements Comparable<Person> {
    /*
        1. Define fields (attributes)
        2. Decide if the class will be mutable or immutable - by default immutable
        3. Make fields private final
        4. Generate getters
        5. Generate constructor
        6. Generate equals() & hashCode()
        7. Generate toString()
        8. Create builder
     */
    private final String firstName;
    private final String lastName;
    private final Address address;
    private final LocalDate birthDate;
    private final boolean alive;
    private final Gender gender;

    private Person(final Builder builder) {
        this.firstName = builder.firstName;
        this.lastName = builder.lastName;
        this.address = builder.address;
        this.birthDate = builder.birthDate;
        this.alive = builder.alive;
        this.gender = builder.gender;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public Address getAddress() {
        return address;
    }

    public LocalDate getBirthDate() {
        return birthDate;
    }

    public boolean isAlive() {
        return alive;
    }

    public Gender getGender() {
        return gender;
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Person)) {
            return false;
        }
        final Person person = (Person) o;
        return alive == person.alive &&
                Objects.equals(firstName, person.firstName) &&
                Objects.equals(lastName, person.lastName) &&
                Objects.equals(address, person.address) &&
                Objects.equals(birthDate, person.birthDate) &&
                gender == person.gender;
    }

    @Override
    public int hashCode() {
        return Objects.hash(firstName, lastName, address, birthDate, alive, gender);
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", Person.class.getSimpleName() + "[", "]")
                .add("firstName='" + firstName + "'")
                .add("lastName='" + lastName + "'")
                .add("address=" + address)
                .add("birthDate=" + birthDate)
                .add("alive=" + alive)
                .add("gender=" + gender)
                .toString();
    }

    public static Builder builder() {
        return new Builder();
    }

    @Override
    public int compareTo(final Person other) {
        if (this == other) {
            return 0;
        }
        if (other == null) {
            return -1;
        }

        final int cmpLastNames = compare(this.getLastName(), other.getLastName());
        if (cmpLastNames != 0) {
            return cmpLastNames;
        }

        return compare(this.getFirstName(), other.getFirstName());
    }

    private int compare(final String s1, final String s2) {
        if (s1 == s2) {
            return 0;
        }
        if (s1 == null) {
            return +1;
        }
        if (s2 == null) {
            return -1;
        }
        return s2.compareToIgnoreCase(s1);
    }

    public static class Builder {
        private String firstName;
        private String lastName;
        private Address address;
        private LocalDate birthDate;
        private boolean alive;
        private Gender gender;

        public Person build() {
            // Here would be consistency checks
            return new Person(this);
        }

        public Builder firstName(final String firstName) {
            this.firstName = firstName;
            return this;
        }

        public Builder lastName(final String lastName) {
            this.lastName = lastName;
            return this;
        }

        public Builder address(final Address address) {
            this.address = address;
            return this;
        }

        public Builder birthDate(final LocalDate birthDate) {
            this.birthDate = birthDate;
            return this;
        }

        public Builder birthDate(final int year, final Month month, final int dayOfMonth) {
            return birthDate(LocalDate.of(year, month, dayOfMonth));
        }

        public Builder alive(final boolean alive) {
            this.alive = alive;
            return this;
        }

        public Builder gender(final Gender gender) {
            this.gender = gender;
            return this;
        }

        private Builder() {
        }
    }
}
