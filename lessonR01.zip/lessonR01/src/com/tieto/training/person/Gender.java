package com.tieto.training.person;

public enum Gender {
    MAN,
    WOMAN;
}
