package com.tieto.training;

public class Cat {
    final private String name;

    public Cat(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public String makeSound() {
        return "miaow";
    }
}
