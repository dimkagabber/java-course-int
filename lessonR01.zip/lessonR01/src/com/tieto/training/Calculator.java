package com.tieto.training;

public class Calculator {
    final private String name;
    final private int q;

    public Calculator(final String name, final int q) {
        this.name = name;
        this.q = q;
    }

    public String getName() {
        return name;
    }

    public int sum(int a, int b) {
        return a + b;
    }

    public int sqr(int a) {
        return a*a;
    }

    public int sumSqr(int a, int b) {
        final int a2 = sqr(a);
        final int b2 = sqr(b);
        final int c = sum(a2, b2);
        return c * this.q;
    }

/*
    public int sumSqr(Calculator this, int a, int b) {
        final int a2 = sqr(a);
        final int b2 = sqr(b);
        final int c = sum(a2, b2);
        return c * this.q;
    }
*/
}
