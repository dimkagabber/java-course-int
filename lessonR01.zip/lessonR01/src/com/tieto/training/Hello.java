package com.tieto.training;

public class Hello {
    public static void main(final String[] arguments) {
        for (byte i = 0; i < 1000; i++) {
            System.out.println(i);
        }
    }
}
