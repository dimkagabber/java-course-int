package com.tieto.training;

import com.tieto.training.person.Person;

import java.util.Arrays;
import java.util.Comparator;

public class ArrayHandlerPerson {
    public Person[] getMax(final Person[] input, final int n, Comparator<Person> comparator) {
        if (n < 0) {
            throw new IllegalArgumentException("Parameter n must be >= 0");
        }
        if (input == null || input.length == 0 || n == 0) {
            return createArray(0);
        }
        if (comparator == null) {
            comparator = Comparator.naturalOrder();
        }

        final Person[] result = createArray(n);
        for (final Person element : input) {
            insertElementToArrayIfBigger(result, element, comparator);
        }
        return trimNulls(result);

    }

    public Person[] getMax(final Person[] input, final int n) {
        return getMax(input, n, null);
    }

    private void insertElementToArrayIfBigger(final Person[] array, final Person newElement, final Comparator<Person> comparator) {
        if (newElement == null) {
            return;
        }
        for (int i = 0; i < array.length; i++) {
            final Person element = array[i];
            if (newElement == element) {
                return;
            }
            if (element == null || comparator.compare(newElement, element) > 0) {
                insertElementToArray(array, newElement, i);
                return;
            }
        }
    }

    private void insertElementToArray(final Person[] array, final Person newElement, final int position) {
        for (int i = array.length - 1; i > position; i--) {
            array[i] = array[i - 1];
        }
        array[position] = newElement;
    }

    private Person[] trimNulls(final Person[] array) {
        for (int i = 0; i < array.length; i++) {
            if (array[i] == null) {
                return Arrays.copyOf(array, i);
            }
        }
        return array;
    }

    private Person[] createArray(final int n) {
        return new Person[n];
    }

}
