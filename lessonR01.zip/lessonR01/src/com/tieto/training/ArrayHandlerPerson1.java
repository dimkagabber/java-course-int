package com.tieto.training;

import com.tieto.training.person.Person;

import java.util.Arrays;

public class ArrayHandlerPerson1 {
    public Person[] getMax(final Person[] input, final int n) {
        if (n < 0) {
            throw new IllegalArgumentException("Parameter n must be >= 0");
        }
        if (input == null || input.length == 0 || n == 0) {
            return createArray(0);
        }

        final Person[] result = createArray(n);
        for (final Person element: input) {
            insertElementToArrayIfBigger(result, element);
        }
        return trimNulls(result);
    }

    private void insertElementToArrayIfBigger(final Person[] array, final Person newElement) {
        if (newElement == null) {
            return;
        }
        for (int i = 0; i < array.length; i++) {
            final Person element = array[i];
            if (newElement == element) {
                return;
            }
            if (element == null || compare(newElement, element) > 0) {
                insertElementToArray(array, newElement, i);
                return;
            }
        }
    }

    int compare(final Person p1, final Person p2) {
        if (p1 == p2) {
            return 0;
        }
        if (p1 == null) {
            return +1;
        }
        if (p2 == null) {
            return -1;
        }

        final int cmpLastNames = compare(p1.getLastName(), p2.getLastName());
        if (cmpLastNames != 0) {
            return cmpLastNames;
        }

        return compare(p1.getFirstName(), p2.getFirstName());
    }

    private int compare(final String s1, final String s2) {
        if (s1 == s2) {
            return 0;
        }
        if (s1 == null) {
            return +1;
        }
        if (s2 == null) {
            return -1;
        }
        return s2.compareToIgnoreCase(s1);
    }

    private void insertElementToArray(final Person[] array, final Person newElement, final int position) {
        for (int i = array.length-1; i > position ; i--) {
            array[i] = array[i-1];
        }
        array[position] = newElement;
    }

    private Person[] trimNulls(final Person[] array) {
        for (int i = 0; i < array.length; i++) {
            if (array[i] == null) {
                return Arrays.copyOf(array, i);
            }
        }
        return array;
    }

    private Person[] createArray(final int n) {
        return new Person[n];
    }
}
