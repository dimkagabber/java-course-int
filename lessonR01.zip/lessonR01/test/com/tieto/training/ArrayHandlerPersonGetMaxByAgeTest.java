package com.tieto.training;

import com.tieto.training.person.Person;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.Month;
import java.util.Comparator;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;

class ArrayHandlerPersonGetMaxByAgeTest {
    private ArrayHandlerPerson ah;
    private Comparator<Person> comparator;

    private final Person P0 = Person.builder()
            .birthDate(LocalDate.of(1950, Month.JANUARY, 31))
            .build();
    private final Person P1 = Person.builder()
            .birthDate(LocalDate.of(1960, Month.JANUARY, 31))
            .build();
    private final Person P2 = Person.builder()
            .birthDate(LocalDate.of(1960, Month.FEBRUARY, 1))
            .build();
    private final Person P3 = Person.builder()
            .birthDate(LocalDate.of(1970, Month.JANUARY, 31))
            .build();
    private final Person P4 = Person.builder()
            .birthDate(LocalDate.of(1980, Month.JANUARY, 31))
            .build();
    private final Person P5 = Person.builder()
            .birthDate(LocalDate.of(1990, Month.JANUARY, 31))
            .build();
    private final Person P6 = Person.builder()
            .birthDate(LocalDate.of(1991, Month.JANUARY, 31))
            .build();
    private final Person P7 = Person.builder()
            .birthDate(LocalDate.of(1992, Month.JANUARY, 31))
            .build();


    @BeforeEach
    void init() {
        ah = new ArrayHandlerPerson();
        comparator = new PersonByAgeComparator();
    }

    @Test
    @DisplayName("getMax() basic scenario")
    void getMaxBasicScenario() {
        final Person[] input = {P6, P0, P2, P7, P0, P3, P2, P1, P5, P4, P4,};
        final Person[] expected = {P0, P1, P2};
        assertArrayEquals(expected, ah.getMax(input, 3, comparator));
    }

    @Test
    @DisplayName("getMax() some elements null")
    void getMaxNullElements() {
        final Person[] input = {null, P6, P0, P2, P7, P0, P3, null, P2, P1, P5, P4, P4,};
        final Person[] expected = {P0, P1, P2};
        assertArrayEquals(expected, ah.getMax(input, 3, comparator));
    }

    @Test
    @DisplayName("getMax() not enough elements")
    void getMaxNotEnoughElements() {
        final Person[] input = {null, P0, P3, P1, P0, P3, null, P3, P1,};
        final Person[] expected = {P0, P1, P3};
        assertArrayEquals(expected, ah.getMax(input, 5, comparator));
    }

    @Test
    @DisplayName("getMax() all the same")
    void getMaxAllSame() {
        final Person[] input = {P7, P7, P7, P7, P7, P7, P7, P7,};
        final Person[] expected = {P7};
        assertArrayEquals(expected, ah.getMax(input, 5, comparator));
    }

    @Test
    @DisplayName("getMax() biggest at the beginning")
    void getMaxBiggestFirst() {
        final Person[] input = {P0, P6, P2, P7, P3, P2, P1, P5, P4, P4,};
        final Person[] expected = {P0, P1, P2, P3};
        assertArrayEquals(expected, ah.getMax(input, 4, comparator));
    }


    @Test
    @DisplayName("getMax() biggest at the end")
    void getMaxBiggestLAst() {
        final Person[] input = {P6, P2, P7, P3, P2, P1, P5, P4, P4, P0};
        final Person[] expected = {P0, P1, P2, P3};
        assertArrayEquals(expected, ah.getMax(input, 4, comparator));
    }

}

class PersonByAgeComparator implements Comparator<Person> {
    @Override
    public int compare(final Person o1, final Person o2) {
        if (o1 == o2) {
            return 0;
        }
        if (o1 == null) {
            return +1;
        }
        if (o2 == null) {
            return -1;
        }
        return compareLocalDates(o1.getBirthDate(), o2.getBirthDate());
    }

    private int compareLocalDates(final LocalDate d1, final LocalDate d2) {
        if (d1 == d2) {
            return 0;
        }
        if (d1 == null) {
            return +1;
        }
        if (d2 == null) {
            return -1;
        }
        return d2.compareTo(d1);
    }
}

