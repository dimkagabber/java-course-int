package com.tieto.training;

import com.tieto.training.person.Person;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ArrayHandlerPersonGetMaxTest {
    private ArrayHandlerPerson ah;

    private final Person P0 = Person.builder()
            .firstName("Adam")
            .lastName("Amarsky")
            .build();
    private final Person P1 = Person.builder()
            .firstName("Bozena")
            .lastName("Blechova")
            .build();
    private final Person P2 = Person.builder()
            .firstName("Cyril")
            .lastName("Coufal")
            .build();
    private final Person P3 = Person.builder()
            .firstName("David")
            .lastName("Dobrovsky")
            .build();
    private final Person P4 = Person.builder()
            .firstName("Emil")
            .lastName("EEEE")
            .build();
    private final Person P5 = Person.builder()
            .firstName("Frantisek")
            .lastName("Ferda")
            .build();
    private final Person P6 = Person.builder()
            .firstName("Gustav")
            .lastName("Gege")
            .build();
    private final Person P7 = Person.builder()
            .firstName("Helena")
            .lastName("Hromska")
            .build();


    @BeforeEach
    void init() {
        ah = new ArrayHandlerPerson();
    }

    @Test
    @DisplayName("getMax() basic scenario")
    void getMaxBasicScenario() {
        final Person[] input = {P6, P0, P2, P7, P0, P3, P2, P1, P5, P4, P4,};
        final Person[] expected = {P0, P1, P2};
        assertArrayEquals(expected, ah.getMax(input, 3));
    }

    @Test
    @DisplayName("getMax() some elements null")
    void getMaxNullElements() {
        final Person[] input = {null, P6, P0, P2, P7, P0, P3, null, P2, P1, P5, P4, P4,};
        final Person[] expected = {P0, P1, P2};
        assertArrayEquals(expected, ah.getMax(input, 3));
    }

    @Test
    @DisplayName("getMax() not enough elements")
    void getMaxNotEnoughElements() {
        final Person[] input = {null, P0, P3, P1, P0, P3, null, P3, P1,};
        final Person[] expected = {P0, P1, P3};
        assertArrayEquals(expected, ah.getMax(input, 5));
    }

    @Test
    @DisplayName("getMax() all the same")
    void getMaxAllSame() {
        final Person[] input = {P7, P7, P7, P7, P7, P7, P7, P7,};
        final Person[] expected = {P7};
        assertArrayEquals(expected, ah.getMax(input, 5));
    }

    @Test
    @DisplayName("getMax() biggest at the beginning")
    void getMaxBiggestFirst() {
        final Person[] input = {P0, P6, P2, P7, P3, P2, P1, P5, P4, P4,};
        final Person[] expected = {P0, P1, P2, P3};
        assertArrayEquals(expected, ah.getMax(input, 4));
    }


    @Test
    @DisplayName("getMax() biggest at the end")
    void getMaxBiggestLAst() {
        final Person[] input = {P6, P2, P7, P3, P2, P1, P5, P4, P4, P0};
        final Person[] expected = {P0, P1, P2, P3};
        assertArrayEquals(expected, ah.getMax(input, 4));
    }
}