package com.tieto.training.person;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.Month;

import static org.junit.jupiter.api.Assertions.*;

class PersonTest {
    @Test
    void personBuilder() {
        final Person p1 = Person.builder()
                .firstName("Martin")
                .lastName("Nometzs")
                .address(Address.builder()
                        .street("Hlavni 13")
                        .city("Frydek-Mistek")
                        .build()
                )
                .birthDate(LocalDate.of(1960, Month.DECEMBER, 31))
                .alive(true)
                .gender(Gender.MAN)
                .build();

        final Person p2 = Person.builder()
                .firstName("Martin")
                .lastName("Nometzs")
                .address(Address.builder()
                        .street("Hlavni 13")
                        .city("Frydek-Mistek")
                        .build()
                )
                .birthDate(LocalDate.of(1960, Month.DECEMBER, 31))
                .alive(true)
                .gender(Gender.MAN)
                .build();

        assertNotSame(p1, p2);
        assertEquals(p1, p2);
    }

    private final Person[] PERSONS = {
            Person.builder()
                    .firstName(null)
                    .lastName(null)
                    .build(),
            Person.builder()
                    .firstName("Karel")
                    .lastName(null)
                    .build(),
            Person.builder()
                    .firstName("")
                    .lastName("")
                    .build(),
            Person.builder()
                    .firstName("Adam")
                    .lastName("")
                    .build(),
            Person.builder()
                    .firstName("Karel")
                    .lastName("")
                    .build(),
            Person.builder()
                    .firstName("Adam")
                    .lastName("Amarsky")
                    .build(),
            Person.builder()
                    .firstName("Bedrich")
                    .lastName("Amarsky")
                    .build(),
            Person.builder()
                    .firstName("Adam")
                    .lastName("Cihelni")
                    .build(),
            Person.builder()
                    .firstName(null)
                    .lastName("Novak")
                    .build()};

    @Test
    @DisplayName("compare() tutti frutti")
    void compare() {
        for (int i = 0; i < PERSONS.length; i++) {
            for (int j = i + 1; j < PERSONS.length; j++) {
                assertTrue(PERSONS[i].compareTo(PERSONS[j]) > 0, "PERSON[" + i + "] > PERSON[" + j + "]");
                assertTrue(PERSONS[j].compareTo(PERSONS[i]) < 0, "PERSON[" + j + "] > PERSON[" + i + "]");
            }
        }
    }

    @Test
    @DisplayName("compare() same instance")
    void compareSameInstance() {
        for (int i = 0; i < PERSONS.length; i++) {
            assertEquals(PERSONS[i].compareTo(PERSONS[i]), 0, "PERSON[" + i + "] == PERSON[" + i + "]");
        }
    }

    @Test
    @DisplayName("compare() equal content")
    void compareEquals() {
        final Person p1 = Person.builder()
                .firstName("Adam")
                .lastName("Amarsky")
                .build();
        final Person p2 = Person.builder()
                .firstName("Adam")
                .lastName("Amarsky")
                .build();
        assertEquals(p1.compareTo(p2), 0);
    }

}