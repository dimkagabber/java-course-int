package com.tieto.training;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class JUnitTest {
    private static int counter = 0;
    JUnitTest() {
        counter++;
        System.out.println("contructor " + counter);
    }
    @BeforeAll
    static void bingBang() {
        System.out.println("before all " + counter);
    }
    @AfterAll
    static void finalCollapse() {
        System.out.println("after all " + counter);
    }
    @BeforeEach
    void init() {
        System.out.println("  before each");
    }
    @AfterEach
    void cleanup() {
        System.out.println("  after each");
    }
    @Test
    void test1() {
        System.out.println("  test1");
    }
    @Test
    void test2() {
        System.out.println("  test2");
    }
    @Test
    void test3() {
        System.out.println("  test3");
    }
}
