package com.tieto.training;

import com.tieto.training.person.Person;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ArrayHandlerPersonCompareTest1 {
    private ArrayHandlerPerson1 ah;

    private final Person[] PERSONS = {
            null,
            Person.builder()
                    .firstName(null)
                    .lastName(null)
                    .build(),
            Person.builder()
                    .firstName("Karel")
                    .lastName(null)
                    .build(),
            Person.builder()
                    .firstName("")
                    .lastName("")
                    .build(),
            Person.builder()
                    .firstName("Adam")
                    .lastName("")
                    .build(),
            Person.builder()
                    .firstName("Karel")
                    .lastName("")
                    .build(),
            Person.builder()
                    .firstName("Adam")
                    .lastName("Amarsky")
                    .build(),
            Person.builder()
                    .firstName("Bedrich")
                    .lastName("Amarsky")
                    .build(),
            Person.builder()
                    .firstName("Adam")
                    .lastName("Cihelni")
                    .build(),
            Person.builder()
                    .firstName(null)
                    .lastName("Novak")
                    .build()};

    @BeforeEach
    void init() {
        ah = new ArrayHandlerPerson1();
    }

    @Test
    @DisplayName("compare() tutti frutti")
    void compare() {
        for (int i = 0; i < PERSONS.length; i++) {
            for (int j = i + 1; j < PERSONS.length; j++) {
                assertTrue(ah.compare(PERSONS[i], PERSONS[j]) > 0, "PERSON[" + i + "] > PERSON[" + j + "]");
                assertTrue(ah.compare(PERSONS[j], PERSONS[i]) < 0, "PERSON[" + j + "] > PERSON[" + i + "]");
            }
        }
    }

    @Test
    @DisplayName("compare() same instance")
    void compareSameInstance() {
        for (int i = 0; i < PERSONS.length; i++) {
            assertEquals(ah.compare(PERSONS[i], PERSONS[i]), 0, "PERSON[" + i + "] == PERSON[" + i + "]");
        }
    }

    @Test
    @DisplayName("compare() equal content")
    void compareEquals() {
        final Person p1 = Person.builder()
                .firstName("Adam")
                .lastName("Amarsky")
                .build();
        final Person p2 = Person.builder()
                .firstName("Adam")
                .lastName("Amarsky")
                .build();
        assertEquals(ah.compare(p1, p2), 0);
    }
}